﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogicLayer;
using BusinessEntity;

namespace Dusharm
{
    public partial class PatientTable : UserControl
    {
        public PatientTable()
        {
            InitializeComponent();
        }
        CRUD_patient_BLL bll = new CRUD_patient_BLL();
        int id;
        
        private void PatientTable_Load(object sender, EventArgs e)
        {
            guna2DataGridView1.AutoGenerateColumns = false;
            guna2DataGridView1.DataSource = null;
            guna2DataGridView1.DataSource = bll.Read();
        }

       
        

        private void guna2DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            id = Convert.ToInt32(guna2DataGridView1.Rows[guna2DataGridView1.CurrentRow.Index].Cells["id"].Value);
        }

        private void guna2DataGridView1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.ColumnIndex != -1 && e.RowIndex != -1 && e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                guna2ContextMenuStrip1.Show(Cursor.Position.X, Cursor.Position.Y);
            }
        }

        private void حذفToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bll.delete(id);
        }

        private void bunifuTextBox1_TextChanged(object sender, EventArgs e)
        {
            guna2DataGridView1.DataSource = null;
            guna2DataGridView1.DataSource = bll.read(bunifuTextBox1.Text);
        }

        //private void ویرایشToolStripMenuItem_Click(object sender, EventArgs e)
        //{
        //    patient p = bll.read(id);

        //    this.Hide();
        //    ReservForm u1 = new ReservForm();

        //    Dusharm f1 = new Dusharm();
        //    f1.panel3.Controls.Add(u1);


        //}


    }
}
