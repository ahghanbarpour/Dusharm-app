﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLogicLayer;

namespace Dusharm
{
    public partial class DoctorTable : UserControl
    {
        public DoctorTable()
        {
            InitializeComponent();
        }
        CRUD_doctor_BLL bll1 = new CRUD_doctor_BLL();

        private void DoctorTable_Load(object sender, EventArgs e)
        {
            guna2DataGridView1.AutoGenerateColumns = false;
            guna2DataGridView1.DataSource = null;
            guna2DataGridView1.DataSource = bll1.Read(); 
        }
    }
}
