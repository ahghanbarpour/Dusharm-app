﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessEntity;
using BusinessLogicLayer;

namespace Dusharm
{
    public partial class ReservForm : UserControl
    {
        public ReservForm()
        {
            InitializeComponent();
        }
        CRUD_patient_BLL bll = new CRUD_patient_BLL();
        CRUD_doctor_BLL bll1 = new CRUD_doctor_BLL();
        bool flag = true;
        int id;
        
        private void bunifuButton21_Click(object sender, EventArgs e)
        {
            patient p = new patient();
            p.name = bunifuTextBox1.Text;
            p.family = bunifuTextBox2.Text;
            p.tel = bunifuTextBox3.Text;
            p.Birthday = maskedTextBox1.Text;
            p.rdate = maskedTextBox2.Text;
            p.rtime = maskedTextBox3.Text;
            doctor d = new doctor();
            d.family = comboBox2.Text;
            d.field = comboBox1.Text;
            d.rdate = maskedTextBox2.Text;
            d.rtime = maskedTextBox3.Text;
            p.doctor = d;
            d.patient = p;

            

            if (flag)
            {
                MessageBox.Show(bll.create(p));
                bll1.create(d);
            }
            else if (!flag)
            {
                MessageBox.Show(bll.update(id, p));
                bll1.update(id, d);
            }

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (Enabled == true)
            {
                bunifuButton21.Enabled = true;
            }
            else
            {
                bunifuButton21.Enabled = false;
            }
        }
    }
}
