﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using BusinessEntity;
using BusinessLogicLayer;
using DataAccessLayer;

namespace Dusharm
{
    public partial class Dusharm : Form
    {
        public Dusharm()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void bunifuImageButton2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            if(panel1.Width == 50)
            {
                //EXPAND
                // 1. Expand the panel.
                // 2. Show logo.
                panel1.Visible = false;
                panel1.Width = 260;
                PanelAnimator.ShowSync(panel1);
                LogoAnimator.ShowSync(pictureBox1);
            }
            else
            {
                //MINIMIZE
                //Using Bunifu Animator
                // 1. Hide the logo.
                // 2. Slide the panel.
                LogoAnimator.Hide(pictureBox1);
                panel1.Visible=false;
                panel1.Width=50;
                PanelAnimator.ShowSync(panel1);
            }
        }

        private void bunifuImageButton1_Click_1(object sender, EventArgs e)
        {
            panel3.Controls.Clear();
            if (panel1.Width == 50)
            {
                //EXPAND
                // 1. Expand the panel.
                // 2. Show logo.
                panel1.Visible = false;
                panel1.Width = 260;
                PanelAnimator.ShowSync(panel1);
                LogoAnimator.ShowSync(pictureBox1);
            }
            else
            {
                //MINIMIZE
                //Using Bunifu Animator
                // 1. Hide the logo.
                // 2. Slide the panel.
                LogoAnimator.Hide(pictureBox1);
                panel1.Visible = false;
                panel1.Width = 50;
                PanelAnimator.ShowSync(panel1);
            }
           
        }
        ReservForm u1 = new ReservForm();
        PatientTable u2 = new PatientTable();
        DoctorTable u3 = new DoctorTable();
        
        private void bunifuButton1_Click(object sender, EventArgs e)
        {
            panel3.Controls.Clear();
            panel3.Controls.Add(u1);
        }

        private void logo_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void bunifuButton2_Click(object sender, EventArgs e)
        {
            panel3.Controls.Clear();
            panel3.Controls.Add(u2);
        }

        private void bunifuButton3_Click(object sender, EventArgs e)
        {
            panel3.Controls.Clear();
            panel3.Controls.Add(u3);
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuButton4_Click(object sender, EventArgs e)
        {
            panel3.Controls.Clear();
        }

        private void bunifuButton5_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
